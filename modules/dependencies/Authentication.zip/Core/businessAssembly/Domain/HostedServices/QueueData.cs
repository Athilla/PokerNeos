﻿using GroupeIsa.Neos.Domain.Entities;

namespace Transversals.Business.Core.Domain.HostedServices
{
    public class QueueData
    {
        public BusinessEntity? Entity { get; set; }
    }
}